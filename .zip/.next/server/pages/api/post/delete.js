"use strict";
(() => {
var exports = {};
exports.id = 137;
exports.ids = [137,748];
exports.modules = {

/***/ 166:
/***/ ((module) => {

module.exports = require("@next-auth/mongodb-adapter");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 7459:
/***/ ((module) => {

module.exports = require("next-auth/providers/github");

/***/ }),

/***/ 6896:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _util_database__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3406);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8013);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5087);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_3__);




async function handler(요청, 응답) {
    // await을 쓰고싶다면 async붙이기
    let session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_3__.getServerSession)(요청, 응답, _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__.authOptions) //현재유저정보가져오기
    ;
    if (요청.method == "POST") {
        let 지울것 = JSON.parse(요청.body);
        console.log(지울것);
        if (session.user.email == 지울것.author) {
            const db = (await _util_database__WEBPACK_IMPORTED_MODULE_0__/* .connectDB */ .u).db("forum") //db에접속
            ;
            let result = await db.collection("post").deleteOne({
                _id: new mongodb__WEBPACK_IMPORTED_MODULE_1__.ObjectId(지울것._id)
            });
            return 응답.status(200).json("삭제 완료");
        }
    }
//result 값을 출력하면 몇개의 db가 삭제되었는지 알 수 있다. 
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [87], () => (__webpack_exec__(6896)));
module.exports = __webpack_exports__;

})();